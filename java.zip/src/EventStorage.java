// File: EventStorage.java

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class EventStorage {
    private static final String FILE_NAME = "events.txt";

    public static void saveEvent(String name, String eventType, String date, String time, String message) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME, true));
        writer.write(name + "," + eventType + "," + date + "," + time + "," + message);
        writer.newLine();
        writer.close();
    }

    public static List<String> getEvents() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME));
        List<String> events = new ArrayList<>();
        String line;
        while ((line = reader.readLine()) != null) {
            events.add(line);
        }
        reader.close();
        return events;
    }
}

