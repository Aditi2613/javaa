// File: VoiceMessage.java

import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;

public class VoiceMessage {
    private static final String VOICE_MESSAGE_FILE = "voiceMessage.wav";

    public static void recordVoiceMessage() {
        try {
            AudioFormat format = new AudioFormat(16000, 8, 2, true, true);
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
            if (!AudioSystem.isLineSupported(info)) {
                System.out.println("Line not supported");
                return;
            }
            TargetDataLine line = (TargetDataLine) AudioSystem.getLine(info);
            line.open(format);
            line.start();
            AudioInputStream ais = new AudioInputStream(line);
            System.out.println("Recording started...");

            File file = new File(VOICE_MESSAGE_FILE);
            AudioSystem.write(ais, AudioFileFormat.Type.WAVE, file);

            System.out.println("Recording stopped.");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void playVoiceMessage() {
        try {
            File file = new File(VOICE_MESSAGE_FILE);
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(file);
            AudioFormat format = audioStream.getFormat();
            DataLine.Info info = new DataLine.Info(Clip.class, format);
            Clip audioClip = (Clip) AudioSystem.getLine(info);
            audioClip.open(audioStream);
            audioClip.start();
            System.out.println("Playing voice message...");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}

