// File: EventReminderApp.java

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.List;

public class EventReminderApp {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Event Reminder");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);

        JPanel panel = new JPanel();
        frame.add(panel);
        placeComponents(panel);

        frame.setVisible(true);

        Reminder.scheduleReminder();
    }

    private static void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(10, 20, 80, 25);
        panel.add(nameLabel);

        JTextField nameText = new JTextField(20);
        nameText.setBounds(100, 20, 165, 25);
        panel.add(nameText);

        JLabel eventTypeLabel = new JLabel("Event Type:");
        eventTypeLabel.setBounds(10, 50, 80, 25);
        panel.add(eventTypeLabel);

        JComboBox<String> eventTypeCombo = new JComboBox<>(new String[]{"Birthday", "Anniversary", "Meeting"});
        eventTypeCombo.setBounds(100, 50, 165, 25);
        panel.add(eventTypeCombo);

        JLabel dateLabel = new JLabel("Date (YYYY-MM-DD):");
        dateLabel.setBounds(10, 80, 150, 25);
        panel.add(dateLabel);

        JTextField dateText = new JTextField(20);
        dateText.setBounds(160, 80, 165, 25);
        panel.add(dateText);

        JLabel timeLabel = new JLabel("Time (HH:MM):");
        timeLabel.setBounds(10, 110, 150, 25);
        panel.add(timeLabel);

        JTextField timeText = new JTextField(20);
        timeText.setBounds(160, 110, 165, 25);
        panel.add(timeText);

        JLabel messageLabel = new JLabel("Message:");
        messageLabel.setBounds(10, 140, 80, 25);
        panel.add(messageLabel);

        JTextField messageText = new JTextField(100);
        messageText.setBounds(100, 140, 165, 50);
        panel.add(messageText);

        JButton recordButton = new JButton("Record Voice Message");
        recordButton.setBounds(10, 200, 200, 25);
        panel.add(recordButton);

        JButton saveButton = new JButton("Save Event");
        saveButton.setBounds(10, 230, 150, 25);
        panel.add(saveButton);

        JButton viewButton = new JButton("View Events");
        viewButton.setBounds(200, 230, 150, 25);
        panel.add(viewButton);

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    EventStorage.saveEvent(
                            nameText.getText(),
                            (String) eventTypeCombo.getSelectedItem(),
                            dateText.getText(),
                            timeText.getText(),
                            messageText.getText()
                    );
                    JOptionPane.showMessageDialog(null, "Event saved!");
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    List<String> events = EventStorage.getEvents();
                    StringBuilder eventList = new StringBuilder();
                    for (String event : events) {
                        eventList.append(event).append("\n");
                    }
                    JOptionPane.showMessageDialog(null, eventList.toString());
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

        recordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VoiceMessage.recordVoiceMessage();
            }
        });
    }
}
