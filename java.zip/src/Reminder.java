// File: Reminder.java

import java.util.Timer;
import java.util.TimerTask;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.IOException;
import java.util.List;

public class Reminder {
    public static void scheduleReminder() {
        Timer timer = new Timer(true);
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                try {
                    List<String> events = EventStorage.getEvents();
                    String now = new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date());
                    for (String event : events) {
                        String[] details = event.split(",");
                        String eventDateTime = details[2] + " " + details[3];
                        if (eventDateTime.equals(now)) {
                            System.out.println("Sending message to " + details[0] + ": " + details[4]);
                            VoiceMessage.playVoiceMessage();
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };
        timer.scheduleAtFixedRate(task, 0, 60 * 1000);
    }
}
